class Room:
    def __init__(self,name):
        self.name=name
        self.chairs=[]
    
    def get_chair(self,chair):
        print(f"{self.name} got chair")
        self.chairs.append(chair.color)
        return self

if __name__=="__main__":
    r=Room("Sierra Madre")
    print(r.name)

    print(r.chairs)
    print(r.get_chair(x1).chairs)
    print(r.get_chair(x2).chairs)

    confrence_r=Room("Yosemiti")

    print(confrence_r.get_chair(x3).chairs)
