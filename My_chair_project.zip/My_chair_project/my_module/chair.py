from my_module.room import Room

class Chair:
    number_of_chairs=0  # is a Class attribute not an instance attribute
    ave_price=20
    def __init__(self,color,size,price): # init is class constructor
        self.color=color   # color and size and price are class attributes
        self.size=size
        self.price=price
        Chair.number_of_chairs+=1

    def chair_roles(self):  # chaire_roles is a method of Chair
       print( " I can role ")
       return self

    def sell_the_chair(self,sell_price=100):
        print(f" We sold the {self.color} chair for {sell_price}")

        profit=sell_price-self.price
        Chair.number_of_chairs-=1
        return profit


class Leather_chair(Chair):

    def __init__(self,color='Black',size=4,price=Chair.ave_price*1.5,quality='Good',place=Room("Siera Madre")):
        super().__init__(color,size,price)
        self.quality=quality
        self.place=place
        self.place.get_chair(self)

    def got_torn(self):
        self.color="Ugly"
        self.quality="Bad"
        self.price/=10
        return self

if __name__=="__main__":    
    x=Leather_chair()
    print(type(x))
    print(x.color)

    print(x.got_torn().color)
    print(x.place.get_chair(x).chairs)
