
# chair


# class Chair:
#     pass


# x=Chair
# print(x)

###### lets make an instance of chair
class Chair:
    def __init__(self):
        self.color="red"
        self.size=3

# let's make an instance of chair
#x=Chair('black')
x=Chair()
print(x.color, x.size)
########
class Chair:
    def __init__(self,abc,numb,f): # init is class constructor
        self.color=abc   # color and size and price are class attributes
        self.size=numb
        self.price=f

    def chair_roles(self):  # chaire_roles is a method of Chair
       print( " I can role ")

    

# let's make an instance of chair
x=Chair('black',5,40)  # a class instance
print(x.color, x.size,x.price)

y=Chair   # a class

x.chair_roles()


########  class 

class Chair:
    number_of_chairs=0  # is a Class attribute not an instance attribute
    ave_price=20
    def __init__(self,color,size,price): # init is class constructor
        self.color=color   # color and size and price are class attributes
        self.size=size
        self.price=price
        Chair.number_of_chairs+=1

    def chair_roles(self):  # chaire_roles is a method of Chair
       print( " I can role ")
       return self

    def sell_the_chair(self,sell_price=100):
        print(f" We sold the {self.color} chair for {sell_price}")

        profit=sell_price-self.price
        Chair.number_of_chairs-=1
        return profit

    

x1=Chair("Red",4,60)
x2=Chair("Black",3,40)
x3=Chair("yellow",5,70)

print(Chair.number_of_chairs)
print(x1.number_of_chairs)

x1.color='Orange'
print(x1.color)

x1.size=2*x1.size
print(x1.size)
print(Chair.number_of_chairs)

print(x1.sell_the_chair())
print(Chair.number_of_chairs)

print(x1.sell_the_chair(150))
print(Chair.number_of_chairs)

class Room:
    def __init__(self,name):
        self.name=name
        self.chairs=[]
    
    def get_chair(self,chair):
        print(f"{self.name} got chair")
        self.chairs.append(chair.color)
        return self

r=Room("Sierra Madre")
print(r.name)

print(r.chairs)
print(r.get_chair(x1).chairs)
print(r.get_chair(x2).chairs)

confrence_r=Room("Yosemiti")

print(confrence_r.get_chair(x3).chairs)



class Leather_chair(Chair):

    def __init__(self,color='Black',size=4,price=Chair.ave_price*1.5,quality='Good',place=Room("Siera Madre")):
        super().__init__(color,size,price)
        self.quality=quality
        self.place=place
        self.place.get_chair(self)

    def got_torn(self):
        self.color="Ugly"
        self.quality="Bad"
        self.price/=10
        return self

    
x=Leather_chair()
print(type(x))
print(x.color)

print(x.got_torn().color)
print(x.place.get_chair(x).chairs)

# r=Room("Siera Madre")
# r.get_chair(x)
# print(r.chairs[0].color)



# class Room:
#     def __init__(self,name):
#         self.name=name
#         self.chairs=[]
    
#     def get_chair(self,chair):

#         print(f"{self.name} got chair")
#         self.chairs.append(chair)
#         return self










