from my_module.room import Room
from my_module.chair import Chair
from my_module.chair import Leather_chair

x=Chair("Red",3,45)
print(x.color)



