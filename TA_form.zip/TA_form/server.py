from flask import Flask, render_template, redirect, request, session

app= Flask(__name__)

app.secret_key="what ever"

@app.route('/')
def home():
    print(" Here !")
    roles=["Teacher","TA"]
    return render_template("user.html",roles=roles)

@app.route('/register',methods=["post"])
def register():

    name=request.form['user']
    session['user']=name

    return redirect('/subjects')

@app.route('/subjects')
def subject():
    # name="Unknown"
    name=session['user']
    return render_template("subjects.html",name=name)

@app.route('/questions',methods=['post'])
def questions():
    print(" we are in questions")
    if "Python" in request.form['subject']:
        return "Python is about Dictionary and ..."
    if "Flask" in request.form['subject']:
        return "Flask is about HTTP request functions"







if __name__=='__main__':
    app.run(debug=True)
